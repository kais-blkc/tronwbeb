export interface TransactionResult {
  success: boolean;
  txHash?: string;
  error?: string;
}
