export const CONTAINER_TYPES = {
  Prisma: Symbol.for('Prisma'),
  NotificationService: Symbol.for('NotificationService'),
  PaymentService: Symbol.for('PaymentService'),
  WalletService: Symbol.for('WalletService'),
  TronService: Symbol.for('TronService'),
};
